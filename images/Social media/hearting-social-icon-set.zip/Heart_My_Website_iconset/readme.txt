------------------
Heart My Website Free Social Icon Set.
22 Social Icons
PNG Format
Three Dimensions - 16x16, 32x32 and 64x64
Designed by http://TheDesignSuperhero.com
------------------

Dear friends,

thank you for downloading this file.

This freebie has been brought to you by SmashingMagazine.com.
You can freely use it for both your private and commercial projects, including software, online services, templates and themes.
The icons may not be resold, sublicensed, rented, transferred or otherwise made available for use. The icons may not be offered for free downloading from websites
other than SmashingMagazine.com.
Please link to the article in which this freebie was released if you would like to spread the word.

Smashing Magazine Team,
www.smashingmagazine.com
